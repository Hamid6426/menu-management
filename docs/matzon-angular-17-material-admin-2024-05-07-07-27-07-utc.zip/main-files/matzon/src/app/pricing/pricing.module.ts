import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PricingRoutingModule } from './pricing-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PricingRoutingModule
  ]
})
export class PricingModule { }
