export interface AppIcon {
    name?: string;
    src?: string;
  }